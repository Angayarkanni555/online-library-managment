<?php
require 'includes/db.php';
require_login();
$title = 'My Books';
$uid = $_SESSION['user']['id'];
$stmt = $pdo->prepare('SELECT br.*, b.title, b.author FROM borrowings br JOIN books b ON b.id = br.book_id WHERE br.user_id = ? ORDER BY br.returned_on IS NULL DESC, br.due_on');
$stmt->execute([$uid]);
$rows = $stmt->fetchAll();
$today = new DateTime('today');
$totalFine = 0;
foreach ($rows as $i => $r) {
    $due = new DateTime($r['due_on']);
    $end = $r['returned_on'] ? new DateTime($r['returned_on']) : $today;
    $lateDays = $end > $due ? $end->diff($due)->days : 0;
    $rows[$i]['fine'] = $lateDays * 2;
    $rows[$i]['active'] = $r['returned_on'] === null;
    $rows[$i]['late'] = $r['returned_on'] === null && $lateDays > 0;
    $rows[$i]['returned'] = $r['returned_on'] !== null;
    $totalFine += $rows[$i]['fine'];
}
$userName = $_SESSION['user']['name'];
?>
<?php include 'includes/header.php'; ?>
<h1>My Books</h1>
<p class="muted">Welcome, <?= e($userName) ?>. Total fine so far: Rs. <?= e($totalFine) ?></p>
<h2>Borrowing history</h2>
<div class="table-wrap">
<table>
  <tr><th>Book</th><th>Borrowed</th><th>Due</th><th>Returned</th><th>Fine (Rs.)</th><th>Status</th><th></th></tr>
  <?php foreach ($rows as $r): ?>
  <tr>
    <td><b><?= e($r['title']) ?></b><br><span class="muted"><?= e($r['author']) ?></span></td>
    <td><?= e($r['borrowed_on']) ?></td>
    <td><?= e($r['due_on']) ?></td>
    <td><?= e($r['returned_on']) ?></td>
    <td><?= e($r['fine']) ?></td>
    <td>
      <?php if ($r['late']): ?><span class="badge b-late">Overdue</span>
      <?php elseif ($r['active']): ?><span class="badge b-ok">Borrowed</span>
      <?php else: ?><span class="badge b-ret">Returned</span>
      <?php endif; ?>
    </td>
    <td>
      <?php if ($r['active']): ?>
      <form method="post" action="return.php" data-confirm="Return this book?">
        <input type="hidden" name="borrowing_id" value="<?= e($r['id']) ?>">
        <button class="btn btn-sm" type="submit">Return</button>
      </form>
      <?php endif; ?>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php include 'includes/footer.php'; ?>
