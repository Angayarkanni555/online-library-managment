<?php
require 'includes/db.php';
require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: dashboard.php'); exit; }

$id = (int)($_POST['borrowing_id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM borrowings WHERE id = ? AND user_id = ? AND returned_on IS NULL');
$stmt->execute([$id, $_SESSION['user']['id']]);
$row = $stmt->fetch();

if ($row) {
    $pdo->prepare('UPDATE borrowings SET returned_on = CURDATE() WHERE id = ?')->execute([$id]);
    $pdo->prepare('UPDATE books SET available = available + 1 WHERE id = ?')->execute([$row['book_id']]);
    flash('Book returned. Thank you!');
} else {
    flash('Record not found.', 'error');
}
header('Location: dashboard.php');
exit;
