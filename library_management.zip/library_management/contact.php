<?php
require 'includes/db.php';
$title = 'Contact';
$errors = [];
$f = ['name' => '', 'email' => '', 'message' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f['name']    = trim($_POST['name'] ?? '');
    $f['email']   = trim($_POST['email'] ?? '');
    $f['message'] = trim($_POST['message'] ?? '');
    if (strlen($f['name']) < 3) $errors[] = 'Name must be at least 3 characters.';
    if (!filter_var($f['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (strlen($f['message']) < 10) $errors[] = 'Message must be at least 10 characters.';
    if (!$errors) {
        $stmt = $pdo->prepare('INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)');
        $stmt->execute([$f['name'], $f['email'], $f['message']]);
        flash('Thank you! Your message has been sent to the librarian.');
        header('Location: contact.php'); exit;
    }
}
?>
<?php include 'includes/header.php'; ?>
<div class="form-box panel">
  <h1>Contact Us</h1>
  <p class="muted">Suggest a book or ask a question.</p>
  <?php foreach ($errors as $er): ?>
    <div class="alert alert-error"><?= e($er) ?></div>
  <?php endforeach; ?>
  <form method="post" action="contact.php" data-validate="contact" novalidate>
    <label>Your name</label>
    <input type="text" name="name" value="<?= e($f['name']) ?>"><div class="err-text"></div>
    <label>Email</label>
    <input type="email" name="email" value="<?= e($f['email']) ?>"><div class="err-text"></div>
    <label>Message</label>
    <textarea name="message" rows="5"><?= e($f['message']) ?></textarea><div class="err-text"></div>
    <button class="btn" type="submit">Send Message</button>
  </form>
</div>
<?php include 'includes/footer.php'; ?>
