<?php
session_start();
session_destroy();
session_start();
$_SESSION['flash'] = ['msg' => 'You have been logged out.', 'type' => 'success'];
header('Location: index.php');
exit;
