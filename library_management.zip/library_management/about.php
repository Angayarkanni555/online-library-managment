<?php
require 'includes/db.php';
$title = 'About';
?>
<?php include 'includes/header.php'; ?>
<h1>About the Library</h1>
<p class="muted">A simple web-based system to manage a college library.</p>
<div class="panel" style="margin-top:18px">
  <h3>Our mission</h3>
  <p>To make the library catalogue available to every student and staff member at any time, and to give librarians an easy way to manage books, members and loans.</p>
  <h3 style="margin-top:16px">Library rules</h3>
  <p>Members may hold books for 14 days. A late fine of Rs. 2 per day is charged for overdue books. Returned copies become available to other members immediately.</p>
  <h3 style="margin-top:16px">Opening hours</h3>
  <p>Monday to Saturday, 9:00 AM to 5:00 PM. The online catalogue is open 24 x 7.</p>
</div>
<?php include 'includes/footer.php'; ?>
