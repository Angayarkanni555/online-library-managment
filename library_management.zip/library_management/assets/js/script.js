// Online Library - client-side interactivity
document.addEventListener('DOMContentLoaded', function () {

  // 1. Mobile menu toggle
  var menuBtn = document.getElementById('menuBtn');
  if (menuBtn) menuBtn.addEventListener('click', function () {
    document.getElementById('mainNav').classList.toggle('open');
  });

  // 2. Live search + category filter on the books page (no page reload)
  var search = document.getElementById('liveSearch');
  var cat = document.getElementById('catFilter');
  var cards = document.querySelectorAll('.book-card');
  function filterBooks() {
    var q = search ? search.value.toLowerCase() : '';
    var c = cat ? cat.value : '';
    var shown = 0;
    cards.forEach(function (card) {
      var ok = card.dataset.text.indexOf(q) !== -1 && (c === '' || card.dataset.cat === c);
      card.style.display = ok ? '' : 'none';
      if (ok) shown++;
    });
    var none = document.getElementById('noResults');
    if (none) none.style.display = shown ? 'none' : 'block';
  }
  if (search) search.addEventListener('input', filterBooks);
  if (cat) cat.addEventListener('change', filterBooks);

  // 3. Form validation
  document.querySelectorAll('form[data-validate]').forEach(function (form) {
    form.addEventListener('submit', function (ev) {
      var valid = true;
      form.querySelectorAll('.err-text').forEach(function (s) { s.textContent = ''; });
      function fail(name, msg) {
        var el = form.querySelector('[name="' + name + '"]');
        if (!el) return;
        var span = el.nextElementSibling;   // the .err-text div placed right after the input
        if (span && span.classList.contains('err-text')) span.textContent = msg;
        valid = false;
      }
      var f = form.elements;
      if (f.name && f.name.value.trim().length < 3) fail('name', 'Name must be at least 3 characters.');
      if (f.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email.value)) fail('email', 'Enter a valid email address.');
      if (f.password && form.dataset.validate === 'register' && !/^(?=.*[A-Za-z])(?=.*\d).{6,}$/.test(f.password.value))
        fail('password', 'Minimum 6 characters with a letter and a number.');
      if (f.password && form.dataset.validate === 'login' && f.password.value === '') fail('password', 'Password is required.');
      if (f.confirm && f.confirm.value !== f.password.value) fail('confirm', 'Passwords do not match.');
      if (f.message && f.message.value.trim().length < 10) fail('message', 'Message must be at least 10 characters.');
      if (f.title && f.title.value.trim() === '') fail('title', 'Title is required.');
      if (f.copies && (parseInt(f.copies.value, 10) < 1 || isNaN(parseInt(f.copies.value, 10)))) fail('copies', 'Copies must be 1 or more.');
      if (!valid) ev.preventDefault();
    });
  });

  // 4. Confirm before destructive / borrow actions
  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('submit', function (ev) {
      if (!confirm(el.dataset.confirm)) ev.preventDefault();
    });
  });
});
