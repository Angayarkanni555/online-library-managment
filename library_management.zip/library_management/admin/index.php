<?php
require '../includes/db.php';
require_admin();
$title = 'Admin Dashboard';
$base = '../';
$totalBooks   = $pdo->query('SELECT COUNT(*) FROM books')->fetchColumn();
$totalMembers = $pdo->query("SELECT COUNT(*) FROM users WHERE role='member'")->fetchColumn();
$issued       = $pdo->query('SELECT COUNT(*) FROM borrowings WHERE returned_on IS NULL')->fetchColumn();
$overdue      = $pdo->query('SELECT COUNT(*) FROM borrowings WHERE returned_on IS NULL AND due_on < CURDATE()')->fetchColumn();
$messages     = $pdo->query('SELECT COUNT(*) FROM contact_messages')->fetchColumn();
$recent = $pdo->query('SELECT br.*, b.title, u.name AS member FROM borrowings br JOIN books b ON b.id = br.book_id JOIN users u ON u.id = br.user_id ORDER BY br.id DESC LIMIT 8')->fetchAll();
foreach ($recent as $i => $r) { $recent[$i]['isReturned'] = $r['returned_on'] !== null; }
$msgs = $pdo->query('SELECT * FROM contact_messages ORDER BY id DESC LIMIT 5')->fetchAll();
?>
<?php include '../includes/header.php'; ?>
<div class="toolbar">
  <div><h1>Admin Dashboard</h1><p class="muted">Overview of the library.</p></div>
  <a class="btn" href="books.php">Manage Books</a>
</div>
<div class="stats">
  <div class="stat"><b><?= $totalBooks ?></b>Total books</div>
  <div class="stat"><b><?= $totalMembers ?></b>Members</div>
  <div class="stat"><b><?= $issued ?></b>Books issued</div>
  <div class="stat"><b><?= $overdue ?></b>Overdue</div>
  <div class="stat"><b><?= $messages ?></b>Messages</div>
</div>

<h2>Recent issue records</h2>
<div class="table-wrap">
<table>
  <tr><th>Member</th><th>Book</th><th>Borrowed</th><th>Due</th><th>Status</th></tr>
  <?php foreach ($recent as $r): ?>
  <tr>
    <td><?= e($r['member']) ?></td>
    <td><?= e($r['title']) ?></td>
    <td><?= e($r['borrowed_on']) ?></td>
    <td><?= e($r['due_on']) ?></td>
    <td>
      <?php if ($r['isReturned']): ?><span class="badge b-ret">Returned</span>
      <?php else: ?><span class="badge b-ok">Issued</span>
      <?php endif; ?>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div>

<h2>Latest contact messages</h2>
<div class="table-wrap">
<table>
  <tr><th>Name</th><th>Email</th><th>Message</th><th>Date</th></tr>
  <?php foreach ($msgs as $m): ?>
  <tr>
    <td><?= e($m['name']) ?></td>
    <td><?= e($m['email']) ?></td>
    <td><?= e($m['message']) ?></td>
    <td><?= e($m['sent_at']) ?></td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php include '../includes/footer.php'; ?>
