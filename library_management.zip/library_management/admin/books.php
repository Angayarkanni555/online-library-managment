<?php
require '../includes/db.php';
require_admin();
$title = 'Manage Books';
$base = '../';

// Delete a book (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $pdo->prepare('DELETE FROM books WHERE id = ?')->execute([(int)$_POST['delete_id']]);
    flash('Book deleted.');
    header('Location: books.php'); exit;
}
$books = $pdo->query('SELECT * FROM books ORDER BY id DESC')->fetchAll();
?>
<?php include '../includes/header.php'; ?>
<div class="toolbar">
  <div><h1>Manage Books</h1><p class="muted">Add, edit or remove books from the catalogue.</p></div>
  <a class="btn" href="book_form.php">+ Add New Book</a>
</div>
<div class="table-wrap">
<table>
  <tr><th>ID</th><th>Title</th><th>Author</th><th>Category</th><th>ISBN</th><th>Copies</th><th>Available</th><th>Actions</th></tr>
  <?php foreach ($books as $b): ?>
  <tr>
    <td><?= e($b['id']) ?></td>
    <td><b><?= e($b['title']) ?></b></td>
    <td><?= e($b['author']) ?></td>
    <td><?= e($b['category']) ?></td>
    <td><?= e($b['isbn']) ?></td>
    <td><?= e($b['copies']) ?></td>
    <td><?= e($b['available']) ?></td>
    <td class="actions">
      <a class="btn btn-sm btn-outline" href="book_form.php?id=<?= e($b['id']) ?>">Edit</a>
      <form method="post" action="books.php" data-confirm="Delete this book permanently?">
        <input type="hidden" name="delete_id" value="<?= e($b['id']) ?>">
        <button class="btn btn-sm btn-danger" type="submit">Delete</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php include '../includes/footer.php'; ?>
