<?php
require '../includes/db.php';
require_admin();
$base = '../';
$id = (int)($_GET['id'] ?? 0);
$f = ['title' => '', 'author' => '', 'category' => '', 'isbn' => '', 'copies' => 1];
$old = null;
if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM books WHERE id = ?');
    $stmt->execute([$id]);
    $old = $stmt->fetch();
    if (!$old) { flash('Book not found.', 'error'); header('Location: books.php'); exit; }
    $f = $old;
}
$title = $id ? 'Edit Book' : 'Add Book';
$heading = $id ? 'Edit book' : 'Add a new book';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = [
        'title'    => trim($_POST['title'] ?? ''),
        'author'   => trim($_POST['author'] ?? ''),
        'category' => trim($_POST['category'] ?? ''),
        'isbn'     => trim($_POST['isbn'] ?? ''),
        'copies'   => (int)($_POST['copies'] ?? 0),
    ];
    if ($f['title'] === '' || $f['author'] === '' || $f['category'] === '') $errors[] = 'Title, author and category are required.';
    if ($f['copies'] < 1) $errors[] = 'Copies must be at least 1.';
    if (!$errors) {
        if ($id) {
            $avail = max(0, $old['available'] + ($f['copies'] - $old['copies']));
            $pdo->prepare('UPDATE books SET title=?, author=?, category=?, isbn=?, copies=?, available=? WHERE id=?')
                ->execute([$f['title'], $f['author'], $f['category'], $f['isbn'], $f['copies'], $avail, $id]);
            flash('Book updated.');
        } else {
            $pdo->prepare('INSERT INTO books (title, author, category, isbn, copies, available) VALUES (?,?,?,?,?,?)')
                ->execute([$f['title'], $f['author'], $f['category'], $f['isbn'], $f['copies'], $f['copies']]);
            flash('Book added to the catalogue.');
        }
        header('Location: books.php'); exit;
    }
}
?>
<?php include '../includes/header.php'; ?>
<div class="form-box panel">
  <h1><?= e($heading) ?></h1>
  <?php foreach ($errors as $er): ?>
    <div class="alert alert-error"><?= e($er) ?></div>
  <?php endforeach; ?>
  <form method="post" data-validate="book" novalidate>
    <label>Title</label>
    <input type="text" name="title" value="<?= e($f['title']) ?>"><div class="err-text"></div>
    <label>Author</label>
    <input type="text" name="author" value="<?= e($f['author']) ?>"><div class="err-text"></div>
    <div class="row">
      <div><label>Category</label><input type="text" name="category" value="<?= e($f['category']) ?>" list="cats"></div>
      <div><label>ISBN</label><input type="text" name="isbn" value="<?= e($f['isbn']) ?>"></div>
    </div>
    <datalist id="cats"><option>Computer Science</option><option>Web Development</option><option>Mathematics</option><option>Science</option><option>Literature</option><option>Biography</option></datalist>
    <label>Number of copies</label>
    <input type="number" name="copies" min="1" value="<?= e($f['copies']) ?>"><div class="err-text"></div>
    <button class="btn" type="submit">Save Book</button>
    <a class="btn btn-outline" href="books.php">Cancel</a>
  </form>
</div>
<?php include '../includes/footer.php'; ?>
