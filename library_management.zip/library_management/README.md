# Online Library Management System

Internet Programming (CS2301) activity - HTML, CSS, JavaScript, PHP and MySQL.

## Features
- Home, Books (catalogue with live + server-side search), About, Contact pages
- User registration and login (password hashing, sessions)
- Members: borrow books (14 days, max 3), return books, view history and fine
- Admin: dashboard, add / edit / delete books, view issue records and messages
- Contact form saves messages to MySQL

## Setup (Windows - XAMPP)
1. Install XAMPP and start **Apache** and **MySQL**.
2. Copy the `library_management` folder to `C:\xampp\htdocs\`.
3. Open http://localhost/phpmyadmin -> Import -> choose `database/library_db.sql` -> Go.
4. Open http://localhost/library_management/
5. If your MySQL has a password, edit `includes/db.php`.

## Demo logins
| Role   | Email                | Password    |
|--------|----------------------|-------------|
| Admin  | admin@library.com    | Admin@123   |
| Member | student@library.com  | Student@123 |

## Folder structure
```
library_management/
  index.php books.php about.php contact.php register.php login.php logout.php
  dashboard.php borrow.php return.php
  admin/   index.php books.php book_form.php
  includes/ db.php header.php footer.php
  assets/  css/style.css  js/script.js
  database/library_db.sql
```
