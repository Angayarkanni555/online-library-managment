<?php
require 'includes/db.php';
$title = 'Register';
$errors = [];
$f = ['name' => '', 'email' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f['name']  = trim($_POST['name'] ?? '');
    $f['email'] = trim($_POST['email'] ?? '');
    $pass = $_POST['password'] ?? '';
    $conf = $_POST['confirm'] ?? '';
    if (strlen($f['name']) < 3) $errors[] = 'Name must be at least 3 characters.';
    if (!filter_var($f['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (!preg_match('/^(?=.*[A-Za-z])(?=.*\d).{6,}$/', $pass)) $errors[] = 'Password needs 6+ characters with a letter and a number.';
    if ($pass !== $conf) $errors[] = 'Passwords do not match.';
    if (!$errors) {
        $chk = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $chk->execute([$f['email']]);
        if ($chk->fetch()) {
            $errors[] = 'This email is already registered.';
        } else {
            $ins = $pdo->prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)');
            $ins->execute([$f['name'], $f['email'], password_hash($pass, PASSWORD_DEFAULT)]);
            flash('Registration successful. Please log in.');
            header('Location: login.php'); exit;
        }
    }
}
?>
<?php include 'includes/header.php'; ?>
<div class="form-box panel">
  <h1>Create account</h1>
  <p class="muted">Become a library member.</p>
  <?php foreach ($errors as $er): ?>
    <div class="alert alert-error"><?= e($er) ?></div>
  <?php endforeach; ?>
  <form method="post" action="register.php" data-validate="register" novalidate>
    <label>Full name</label>
    <input type="text" name="name" value="<?= e($f['name']) ?>"><div class="err-text"></div>
    <label>Email</label>
    <input type="email" name="email" value="<?= e($f['email']) ?>"><div class="err-text"></div>
    <label>Password</label>
    <input type="password" name="password"><div class="err-text"></div>
    <label>Confirm password</label>
    <input type="password" name="confirm"><div class="err-text"></div>
    <button class="btn" type="submit">Register</button>
  </form>
  <p class="muted" style="margin-top:14px">Already a member? <a href="login.php">Log in</a></p>
</div>
<?php include 'includes/footer.php'; ?>
