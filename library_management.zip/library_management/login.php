<?php
require 'includes/db.php';
$title = 'Login';
$errors = [];
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';
    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if ($user && password_verify($pass, $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => $user['id'], 'name' => $user['name'], 'role' => $user['role']];
        flash('Welcome back, ' . $user['name'] . '!');
        header('Location: ' . ($user['role'] === 'admin' ? 'admin/index.php' : 'dashboard.php')); exit;
    }
    $errors[] = 'Invalid email or password.';
}
?>
<?php include 'includes/header.php'; ?>
<div class="form-box panel">
  <h1>Member login</h1>
  <p class="muted">Demo: student@library.com / Student@123</p>
  <?php foreach ($errors as $er): ?>
    <div class="alert alert-error"><?= e($er) ?></div>
  <?php endforeach; ?>
  <form method="post" action="login.php" data-validate="login" novalidate>
    <label>Email</label>
    <input type="email" name="email" value="<?= e($email) ?>"><div class="err-text"></div>
    <label>Password</label>
    <input type="password" name="password"><div class="err-text"></div>
    <button class="btn" type="submit">Login</button>
  </form>
  <p class="muted" style="margin-top:14px">New here? <a href="register.php">Create an account</a></p>
</div>
<?php include 'includes/footer.php'; ?>
