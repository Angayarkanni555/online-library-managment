-- Online Library Management System - database script
-- Import with phpMyAdmin (Import tab) or: mysql -u root < library_db.sql
CREATE DATABASE IF NOT EXISTS library_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE library_db;

DROP TABLE IF EXISTS borrowings;
DROP TABLE IF EXISTS contact_messages;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('member','admin') NOT NULL DEFAULT 'member',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  author VARCHAR(100) NOT NULL,
  category VARCHAR(50) NOT NULL,
  isbn VARCHAR(20),
  copies INT NOT NULL DEFAULT 1,
  available INT NOT NULL DEFAULT 1,
  added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE borrowings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  book_id INT NOT NULL,
  borrowed_on DATE NOT NULL,
  due_on DATE NOT NULL,
  returned_on DATE DEFAULT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
);

CREATE TABLE contact_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  email VARCHAR(120) NOT NULL,
  message TEXT NOT NULL,
  sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Demo accounts: admin@library.com / Admin@123   and   student@library.com / Student@123
INSERT INTO users (name, email, password, role) VALUES
('Library Admin', 'admin@library.com', '$6$wiNTBu8afYww8oqe$Ywc1tqTCgpTPiB5d0PGN90vCLhKwoaepOVy8EcBGHBN2lyWBU/mmYAc87XPANuOBrMYmEcBcZUFu6TZc8P0bm0', 'admin'),
('Demo Student', 'student@library.com', '$6$O3YUUHCpi6YbeeJ2$DLHszNsDrcGChXwxjAd.8oi.Z.qeu0z8oPGWg69c1Cwls84RF0NzaiKWNeO/YprLaIhnx5nTNPjTCI8caW1s3.', 'member');

INSERT INTO books (title, author, category, isbn, copies, available) VALUES
('Introduction to Algorithms', 'Thomas H. Cormen', 'Computer Science', '9780262033848', 5, 4),
('Clean Code', 'Robert C. Martin', 'Computer Science', '9780132350884', 4, 4),
('Operating System Concepts', 'Abraham Silberschatz', 'Computer Science', '9781119800361', 6, 6),
('Database System Concepts', 'Henry F. Korth', 'Computer Science', '9780078022159', 4, 3),
('Computer Networks', 'Andrew S. Tanenbaum', 'Computer Science', '9780132126953', 3, 3),
('Learning PHP, MySQL & JavaScript', 'Robin Nixon', 'Web Development', '9781492093824', 4, 4),
('JavaScript: The Good Parts', 'Douglas Crockford', 'Web Development', '9780596517748', 3, 2),
('HTML and CSS: Design and Build Websites', 'Jon Duckett', 'Web Development', '9781118008188', 5, 5),
('Higher Engineering Mathematics', 'B. S. Grewal', 'Mathematics', '9788174091956', 8, 8),
('Discrete Mathematics and Its Applications', 'Kenneth H. Rosen', 'Mathematics', '9781259676512', 4, 4),
('Engineering Physics', 'Gaur and Gupta', 'Science', '9788187433415', 5, 5),
('A Brief History of Time', 'Stephen Hawking', 'Science', '9780553380163', 3, 3),
('Wings of Fire', 'A. P. J. Abdul Kalam', 'Biography', '9788173711466', 6, 5),
('The Story of My Experiments with Truth', 'M. K. Gandhi', 'Biography', '9780486245935', 3, 3),
('Ponniyin Selvan', 'Kalki Krishnamurthy', 'Literature', '9788184930061', 4, 4),
('Malgudi Days', 'R. K. Narayan', 'Literature', '9780143039655', 4, 4),
('The Alchemist', 'Paulo Coelho', 'Literature', '9780062315007', 5, 4),
('Rich Dad Poor Dad', 'Robert T. Kiyosaki', 'Business', '9781612680194', 3, 3),
('Python Crash Course', 'Eric Matthes', 'Computer Science', '9781718502703', 4, 3),
('Artificial Intelligence: A Modern Approach', 'Stuart Russell', 'Computer Science', '9780134610993', 3, 3);

INSERT INTO borrowings (user_id, book_id, borrowed_on, due_on, returned_on) VALUES
(2, 1, DATE_SUB(CURDATE(), INTERVAL 5 DAY),  DATE_ADD(CURDATE(), INTERVAL 9 DAY),  NULL),
(2, 13, DATE_SUB(CURDATE(), INTERVAL 20 DAY), DATE_SUB(CURDATE(), INTERVAL 6 DAY), NULL),
(2, 6, DATE_SUB(CURDATE(), INTERVAL 40 DAY), DATE_SUB(CURDATE(), INTERVAL 26 DAY), DATE_SUB(CURDATE(), INTERVAL 28 DAY));

INSERT INTO contact_messages (name, email, message) VALUES
('Ravi Kumar', 'ravi@example.com', 'Please add more books on machine learning.');
