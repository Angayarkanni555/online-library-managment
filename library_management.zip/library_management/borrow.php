<?php
require 'includes/db.php';
require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: books.php'); exit; }

$bookId = (int)($_POST['book_id'] ?? 0);
$userId = $_SESSION['user']['id'];

try {
    $pdo->beginTransaction();
    $stmt = $pdo->prepare('SELECT * FROM books WHERE id = ? FOR UPDATE');
    $stmt->execute([$bookId]);
    $book = $stmt->fetch();

    $dup = $pdo->prepare('SELECT COUNT(*) FROM borrowings WHERE user_id = ? AND book_id = ? AND returned_on IS NULL');
    $dup->execute([$userId, $bookId]);
    $count = $pdo->prepare('SELECT COUNT(*) FROM borrowings WHERE user_id = ? AND returned_on IS NULL');
    $count->execute([$userId]);

    if (!$book || $book['available'] < 1) {
        flash('Sorry, this book is not available.', 'error');
    } elseif ($dup->fetchColumn() > 0) {
        flash('You have already borrowed this book.', 'error');
    } elseif ($count->fetchColumn() >= 3) {
        flash('You can borrow at most 3 books at a time.', 'error');
    } else {
        $pdo->prepare('INSERT INTO borrowings (user_id, book_id, borrowed_on, due_on) VALUES (?, ?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 14 DAY))')
            ->execute([$userId, $bookId]);
        $pdo->prepare('UPDATE books SET available = available - 1 WHERE id = ?')->execute([$bookId]);
        flash('Book borrowed. Please return it within 14 days.');
    }
    $pdo->commit();
} catch (Exception $ex) {
    $pdo->rollBack();
    flash('Something went wrong. Please try again.', 'error');
}
header('Location: dashboard.php');
exit;
