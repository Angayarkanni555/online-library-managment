<?php
require 'includes/db.php';
$title = 'Books';
$q = trim($_GET['q'] ?? '');
$cat = $_GET['category'] ?? '';

// Server-side search (works even without JavaScript)
$sql = 'SELECT * FROM books WHERE (title LIKE :q OR author LIKE :q OR isbn LIKE :q)';
$params = [':q' => "%$q%"];
if ($cat !== '') { $sql .= ' AND category = :c'; $params[':c'] = $cat; }
$sql .= ' ORDER BY title';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();
foreach ($books as $i => $b) {
    $books[$i]['letter'] = strtoupper(substr($b['title'], 0, 1));
    $books[$i]['color']  = 'c' . (($b['id'] % 6) + 1);
    $books[$i]['search'] = strtolower($b['title'] . ' ' . $b['author'] . ' ' . $b['isbn']);
    $books[$i]['inStock'] = $b['available'] > 0;
}
$categories = $pdo->query('SELECT DISTINCT category FROM books ORDER BY category')->fetchAll(PDO::FETCH_COLUMN);
$loggedIn = !empty($_SESSION['user']);
?>
<?php include 'includes/header.php'; ?>
<h1>Book Catalogue</h1>
<p class="muted">Type to filter instantly, or press Enter to search on the server.</p>

<form class="filters" method="get" action="books.php">
  <input type="text" id="liveSearch" name="q" value="<?= e($q) ?>" placeholder="Search by title, author or ISBN">
  <select id="catFilter" name="category">
    <option value="">All categories</option>
    <?php foreach ($categories as $c): ?>
      <option value="<?= e($c) ?>" <?= $cat == $c ? 'selected' : '' ?>><?= e($c) ?></option>
    <?php endforeach; ?>
  </select>
  <button class="btn" type="submit">Search</button>
</form>

<div class="grid">
<?php foreach ($books as $b): ?>
  <div class="card book-card" data-text="<?= e($b['search']) ?>" data-cat="<?= e($b['category']) ?>">
    <div class="cover <?= $b['color'] ?>"><?= e($b['letter']) ?></div>
    <div class="card-body">
      <span class="tag"><?= e($b['category']) ?></span>
      <h3><?= e($b['title']) ?></h3>
      <span class="muted"><?= e($b['author']) ?></span>
      <?php if ($b['inStock']): ?>
        <span class="avail in"><?= e($b['available']) ?> of <?= e($b['copies']) ?> copies available</span>
      <?php else: ?>
        <span class="avail out">All copies issued</span>
      <?php endif; ?>
      <?php if ($loggedIn && $b['inStock']): ?>
        <form method="post" action="borrow.php" data-confirm="Borrow this book for 14 days?">
          <input type="hidden" name="book_id" value="<?= e($b['id']) ?>">
          <button class="btn btn-sm" type="submit">Borrow</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
<?php endforeach; ?>
</div>
<p id="noResults" class="muted" style="display:none;margin-top:16px">No books match your search.</p>
<?php include 'includes/footer.php'; ?>
