<?php
require 'includes/db.php';
$title = 'Home';
$totalBooks   = $pdo->query('SELECT COUNT(*) FROM books')->fetchColumn();
$totalMembers = $pdo->query("SELECT COUNT(*) FROM users WHERE role='member'")->fetchColumn();
$issued       = $pdo->query('SELECT COUNT(*) FROM borrowings WHERE returned_on IS NULL')->fetchColumn();
$totalCats    = $pdo->query('SELECT COUNT(DISTINCT category) FROM books')->fetchColumn();
$latest = $pdo->query('SELECT * FROM books ORDER BY id DESC LIMIT 4')->fetchAll();
foreach ($latest as $i => $b) { $latest[$i]['letter'] = strtoupper(substr($b['title'], 0, 1)); $latest[$i]['color'] = 'c' . (($b['id'] % 6) + 1); }
?>
<?php include 'includes/header.php'; ?>
<section class="hero">
  <h1>Discover, borrow and manage books online</h1>
  <p>Search the library catalogue, borrow books with one click and track your due dates from anywhere.</p>
  <a class="btn" href="books.php">Browse Books</a>
  <?php if (!$loggedIn): ?>
    <a class="btn btn-outline" href="register.php">Join the Library</a>
  <?php endif; ?>
</section>

<div class="stats">
  <div class="stat"><b><?= $totalBooks ?></b>Books in catalogue</div>
  <div class="stat"><b><?= $totalCats ?></b>Categories</div>
  <div class="stat"><b><?= $totalMembers ?></b>Registered members</div>
  <div class="stat"><b><?= $issued ?></b>Books currently issued</div>
</div>

<h2>Newly added books</h2>
<div class="grid">
<?php foreach ($latest as $b): ?>
  <div class="card">
    <div class="cover <?= $b['color'] ?>"><?= e($b['letter']) ?></div>
    <div class="card-body">
      <span class="tag"><?= e($b['category']) ?></span>
      <h3><?= e($b['title']) ?></h3>
      <span class="muted"><?= e($b['author']) ?></span>
    </div>
  </div>
<?php endforeach; ?>
</div>

<h2>How it works</h2>
<div class="stats">
  <div class="stat"><b>1</b>Register a free member account</div>
  <div class="stat"><b>2</b>Search the catalogue and borrow a book</div>
  <div class="stat"><b>3</b>Return it within 14 days to avoid fines</div>
</div>
<?php include 'includes/footer.php'; ?>
