<?php
$loggedIn = !empty($_SESSION['user']);
$isAdmin  = $loggedIn && $_SESSION['user']['role'] === 'admin';
$userName = $loggedIn ? $_SESSION['user']['name'] : '';
$flashMsg = flash();
if (!isset($base)) { $base = ''; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> | Online Library</title>
<link rel="stylesheet" href="<?= $base ?>assets/css/style.css">
</head>
<body>
<header class="site-header">
  <div class="container nav">
    <a class="brand" href="<?= $base ?>index.php"><span class="logo">L</span> Online Library</a>
    <button class="menu-btn" id="menuBtn" aria-label="Menu">&#9776;</button>
    <nav id="mainNav">
      <a href="<?= $base ?>index.php">Home</a>
      <a href="<?= $base ?>books.php">Books</a>
      <a href="<?= $base ?>about.php">About</a>
      <a href="<?= $base ?>contact.php">Contact</a>
      <?php if ($isAdmin): ?>
        <a href="<?= $base ?>admin/index.php">Admin</a>
      <?php endif; ?>
      <?php if ($loggedIn): ?>
        <a href="<?= $base ?>dashboard.php">My Books</a>
        <a class="btn btn-outline" href="<?= $base ?>logout.php">Logout (<?= e($userName) ?>)</a>
      <?php else: ?>
        <a href="<?= $base ?>login.php">Login</a>
        <a class="btn" href="<?= $base ?>register.php">Register</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main class="container">
<?php if ($flashMsg): ?>
  <div class="alert alert-<?= e($flashMsg['type']) ?>"><?= e($flashMsg['msg']) ?></div>
<?php endif; ?>
