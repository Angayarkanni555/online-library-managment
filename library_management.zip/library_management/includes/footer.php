<?php // footer ?>
</main>
<footer class="site-footer">
  <div class="container">
    <p>&copy; 2026 Online Library Management System &middot; Internet Programming (CS2301) Activity</p>
  </div>
</footer>
<script src="<?= $base ?>assets/js/script.js"></script>
</body>
</html>
