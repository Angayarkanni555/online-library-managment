<?php
// Database connection (PDO) and common helper functions
session_start();

$DB_HOST = 'localhost';
$DB_NAME = 'library_db';
$DB_USER = 'root';
$DB_PASS = '';          // XAMPP default is empty

try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $ex) {
    die('Database connection failed. Import database/library_db.sql first.');
}

function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function flash($msg = null, $type = 'success') {
    if ($msg !== null) { $_SESSION['flash'] = ['msg' => $msg, 'type' => $type]; return null; }
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

function require_login() {
    if (empty($_SESSION['user'])) { flash('Please log in first.', 'error'); header('Location: login.php'); exit; }
}

function require_admin() {
    if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
        flash('Admin access only.', 'error'); header('Location: ../login.php'); exit;
    }
}
